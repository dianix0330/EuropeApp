import { useState, useEffect, useMemo } from "react";
import { NationCard } from "./components";
import { INation } from "./types";
import "./App.css";

const App = () => {
  const [loading, setLoading] = useState(false);
  const [nations, setNations] = useState<INation[]>([]);
  const [currentSubRegion, setCurrentSubRegion] = useState("All");
  const [sortOrder, setSortOrder] = useState("asc");

  const regionOptions = useMemo(
    () => [
      "All",
      ...Array.from(new Set(nations.map((nation) => nation.subregion))),
    ],
    [nations]
  );

  const filteredNations = useMemo(() => {
    let result = nations;

    if (currentSubRegion && currentSubRegion !== "All")
      result = nations.filter(
        (nation) => nation.subregion === currentSubRegion
      );

    result.sort((a, b) => {
      if (sortOrder === "asc")
        return a.name.common.toLowerCase().localeCompare(b.name.common);

      return b.name.common.toLowerCase().localeCompare(a.name.common);
    });

    return result;
  }, [nations, currentSubRegion, sortOrder]);

  useEffect(() => {
    setLoading(true);

    fetch(process.env.REACT_APP_REGION_URL || "")
      .then((response) => response.json())
      .then((data) => {
        setNations(data);
        setLoading(false);
      });
  }, []);

  return (
    <div className="container">
      {loading || !nations ? (
        <div className="loading_spinner"></div>
      ) : (
        <>
          <div className="settings">
            <label htmlFor="sortOrder" className="label">
              Sort:{" "}
            </label>

            <select
              className="setting__select"
              id="sortOrder"
              value={sortOrder}
              onChange={(e) => setSortOrder(e.target.value)}
            >
              <option value="desc">Descending Order</option>
              <option value="asc">Ascending Order</option>
            </select>

            <label htmlFor="subRegion" className="label">
              Sub Region:{" "}
            </label>

            <select
              className="setting__select"
              id="subRegion"
              value={currentSubRegion}
              onChange={(e) => setCurrentSubRegion(e.target.value)}
            >
              {regionOptions.map((region, index) => (
                <option key={index} value={region}>
                  {region}
                </option>
              ))}
            </select>
          </div>

          <div className="card__container">
            {filteredNations.map(
              (
                {
                  name: { common },
                  flags: { png },
                  subregion,
                  capital,
                  population,
                  languages,
                },
                index
              ) => (
                <NationCard
                  key={index}
                  name={common}
                  flagURL={png}
                  subregion={subregion}
                  capital={capital.join("")}
                  population={population}
                  language={languages}
                />
              )
            )}
          </div>
        </>
      )}
    </div>
  );
};

export default App;
